import fs from 'fs';
import path from 'path';
import {
  DEFAULT_COMPANIES,
  DEFAULT_COMPENSATION_REQUESTS,
  DEFAULT_PHONE_CHANGE_REQUESTS,
  DEFAULT_TELEGRAM_CONFIG,
  DEFAULT_APP_BRANDING,
  DEFAULT_NOTIFICATIONS,
  ServerCompensationRequest,
  ServerPhoneChangeRequest,
} from './seedData';
import { Company } from '../src/types';

const DATA_DIR = path.join(process.cwd(), 'data');

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function readJsonFile<T>(filename: string, defaultData: T): T {
  ensureDataDir();
  const filePath = path.join(DATA_DIR, filename);
  if (!fs.existsSync(filePath)) {
    writeJsonFile(filename, defaultData);
    return defaultData;
  }
  try {
    const raw = fs.readFileSync(filePath, 'utf-8');
    if (!raw.trim()) {
      writeJsonFile(filename, defaultData);
      return defaultData;
    }
    return JSON.parse(raw) as T;
  } catch (err) {
    console.warn(`[Storage] Failed to read ${filename}, falling back to defaults:`, err);
    writeJsonFile(filename, defaultData);
    return defaultData;
  }
}

function writeJsonFile<T>(filename: string, data: T): void {
  ensureDataDir();
  const filePath = path.join(DATA_DIR, filename);
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error(`[Storage] Failed to write ${filename}:`, err);
  }
}

// -------------------------------------------------------------
// Storage Managers
// -------------------------------------------------------------

export const storage = {
  // 1. Companies
  getCompanies(): Company[] {
    return readJsonFile<Company[]>('companies.json', DEFAULT_COMPANIES);
  },
  saveCompanies(companies: Company[]): void {
    writeJsonFile('companies.json', companies);
  },
  saveCompany(company: Company): Company[] {
    const list = this.getCompanies();
    const idx = list.findIndex((c) => c.id === company.id);
    if (idx >= 0) {
      list[idx] = { ...list[idx], ...company };
    } else {
      list.push(company);
    }
    this.saveCompanies(list);
    return list;
  },
  toggleCompanyActive(companyId: string): { success: boolean; is_active: boolean } {
    const list = this.getCompanies();
    const comp = list.find((c) => c.id === companyId);
    if (!comp) return { success: false, is_active: false };
    comp.is_active = !comp.is_active;
    this.saveCompanies(list);
    return { success: true, is_active: comp.is_active };
  },

  // 2. Compensation & Unfreeze Requests
  getCompensationRequests(): ServerCompensationRequest[] {
    return readJsonFile<ServerCompensationRequest[]>('compensation_requests.json', DEFAULT_COMPENSATION_REQUESTS);
  },
  saveCompensationRequests(requests: ServerCompensationRequest[]): void {
    writeJsonFile('compensation_requests.json', requests);
  },
  addCompensationRequest(req: ServerCompensationRequest): ServerCompensationRequest {
    const list = this.getCompensationRequests();
    list.unshift(req);
    this.saveCompensationRequests(list);
    return req;
  },
  updateCompensationRequest(
    id: string,
    updates: Partial<ServerCompensationRequest>
  ): ServerCompensationRequest | null {
    const list = this.getCompensationRequests();
    const idx = list.findIndex((r) => r.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...updates };
    this.saveCompensationRequests(list);
    return list[idx];
  },

  // 3. Phone Change Requests
  getPhoneChangeRequests(): ServerPhoneChangeRequest[] {
    return readJsonFile<ServerPhoneChangeRequest[]>('phone_change_requests.json', DEFAULT_PHONE_CHANGE_REQUESTS);
  },
  savePhoneChangeRequests(requests: ServerPhoneChangeRequest[]): void {
    writeJsonFile('phone_change_requests.json', requests);
  },
  addPhoneChangeRequest(req: ServerPhoneChangeRequest): ServerPhoneChangeRequest {
    const list = this.getPhoneChangeRequests();
    list.unshift(req);
    this.savePhoneChangeRequests(list);
    return req;
  },
  updatePhoneChangeRequest(
    id: string,
    updates: Partial<ServerPhoneChangeRequest>
  ): ServerPhoneChangeRequest | null {
    const list = this.getPhoneChangeRequests();
    const idx = list.findIndex((r) => r.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...updates };
    this.savePhoneChangeRequests(list);
    return list[idx];
  },

  // 4. App Branding
  getAppBranding(): any {
    return readJsonFile('app_branding.json', DEFAULT_APP_BRANDING);
  },
  saveAppBranding(branding: any): void {
    writeJsonFile('app_branding.json', branding);
  },

  // 5. Telegram Configuration
  getTelegramConfig(): any {
    return readJsonFile('telegram_config.json', DEFAULT_TELEGRAM_CONFIG);
  },
  saveTelegramConfig(config: any): void {
    writeJsonFile('telegram_config.json', config);
  },

  // 6. Notifications
  getNotifications(): any[] {
    return readJsonFile<any[]>('notifications.json', DEFAULT_NOTIFICATIONS);
  },
  saveNotifications(notifs: any[]): void {
    writeJsonFile('notifications.json', notifs);
  },
  addNotification(notif: any): any {
    const list = this.getNotifications();
    list.unshift(notif);
    this.saveNotifications(list);
    return notif;
  },

  // 7. Complete Replica Restore & Seed Reset
  restoreAllReplicaData(): {
    success: boolean;
    companiesCount: number;
    requestsCount: number;
    phoneRequestsCount: number;
    notificationsCount: number;
  } {
    this.saveCompanies(DEFAULT_COMPANIES);
    this.saveCompensationRequests(DEFAULT_COMPENSATION_REQUESTS);
    this.savePhoneChangeRequests(DEFAULT_PHONE_CHANGE_REQUESTS);
    this.saveAppBranding(DEFAULT_APP_BRANDING);
    this.saveTelegramConfig(DEFAULT_TELEGRAM_CONFIG);
    this.saveNotifications(DEFAULT_NOTIFICATIONS);

    return {
      success: true,
      companiesCount: DEFAULT_COMPANIES.length,
      requestsCount: DEFAULT_COMPENSATION_REQUESTS.length,
      phoneRequestsCount: DEFAULT_PHONE_CHANGE_REQUESTS.length,
      notificationsCount: DEFAULT_NOTIFICATIONS.length,
    };
  },
};

// Initial verification and seed on boot
ensureDataDir();
storage.getCompanies();
storage.getCompensationRequests();
storage.getPhoneChangeRequests();
storage.getAppBranding();
storage.getTelegramConfig();
storage.getNotifications();
